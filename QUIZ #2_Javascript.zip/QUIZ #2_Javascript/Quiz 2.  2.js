var num1 = 10;
var num2 = 20;

if (num2 > num1) {
    console.log("num2 is greater.");
} else if (num1 > num2) {
    console.log("num1 is greater.");
} else {
    console.log("Both numbers are equal.");
}
