<?php
$age = 20
if ($age >= 18) {
    echo "You are eligible to vote.";
}else {
    echo "You are not eligible to vote.";
}
?>