<?php
echo "Hello world!";
?>