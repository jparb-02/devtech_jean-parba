var number = 10;
if (number % 2 === 0) {
        console.log ("this is even number");
    } else {
console.log ("this is odd"); 
    }
