<?php

$conn = new mysqli("localhost", "root", "", "form_db");


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$name = $_POST['name'];
$favorite_movie = $_POST['favorite_movie'];
$degree = $_POST['degree'];
$gender = $_POST['gender'];
$favorite_units = implode(", ", $_POST['favorite_units']); 


$sql = "INSERT INTO form_responses (name, favorite_movie, degree, gender, favorite_units) 
        VALUES ('$name', '$favorite_movie', '$degree', '$gender', '$favorite_units')";


if ($conn->query($sql) === TRUE) {
    echo "<h1>Hello $name</h1>";
    echo "<p>You like movie \"$favorite_movie\".</p>";
    echo "<p>You are enrolled in $degree's Degree.</p>";
    echo "<p>Your gender is $gender.</p>";
    echo "<p>Your favorite subjects are $favorite_units.</p>";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
