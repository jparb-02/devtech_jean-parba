<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Post Form</title>
</head>
<body>
    <h1 style= "background-color:blue;"> Postform.php </h1>
    <form action="postform_submitted.php" method="POST">
        <label for="name">My name is:</label>
        <input type="text" id="name" name="name" required><br><br>

        <label for="favorite_movie">My favorite movie is:</label>
        <input type="text" id="favorite_movie" name="favorite_movie" required><br><br>

        <label for="degree">My degree is:</label>
        <select id="degree" name="degree">
            <option value="Bachelor">Bachelor</option>
            <option value="Master">Master</option>
            <option value="PhD">PhD</option>
        </select><br><br>

        <label>Gender:</label>
        <input type="radio" name="gender" value="Male" required> Male
        <input type="radio" name="gender" value="Female" required> Female<br><br>


        <label for="favorite_units">My favorite unit(s):</label><br>
        <select id="favorite_units" name="favorite_units[]" multiple>
            <option value="Math">Math</option>
            <option value="Science">Science</option>
            <option value="History">History</option>
            <option value="Art">Art</option>
        </select><br><br>

        <button type="submit">Submit</button>
    </form>
</body>
</html>
